//Clique no botão de iniciar o código para ver uma pequena animação!



let tempo = 0; // isso vai servir pra controla a passagem de tempo, pra comseguir dividir em fases
let arvores = []; // uso pra guardar as arvores pois vou usar várias
let animais = []; // isso é pra guardar os animais, já que vai ter vários

function setup() {
  createCanvas(800, 400); //decidi fazer meio grande pra ficar mais facil, quanto menor mais complicado
  frameRate(30); // isso define a taxa de quadros da "animação"
}

function draw() {
  background(lerpColor(color(100), color(135, 206, 235), min(tempo / 600.0, 1)));

  desenharChao();

  if (tempo < 300) {
    desenharIndustria();
    desenharFumaca();
  } else if (tempo < 600) {
    desenharIndustriaSemFumaca();
    desenharGrama((tempo - 300) / 300.0);
  } else {
    desenharGrama(1);
    crescerFloresta();
    mostrarAnimais();
    mostrarTexto();
  }

  tempo++;
}

// parte 1 vai iniciar um cenário poluído com fumaça que vai ser o inicio

function desenharIndustria() {
  fill(80);
  rect(100, 250, 120, 100);
  rect(130, 200, 20, 50);
}

function desenharFumaca() {
  fill(100, 100);
  for (let i = 0; i < 10; i++) {
    ellipse(140 + random(-10, 10), 180 - i * 15 + random(-5, 5), 30, 20);
  }
}

// parte 2 o fim da poluição
function desenharIndustriaSemFumaca() {
  fill(100);
  rect(100, 250, 120, 100);
  rect(130, 200, 20, 50);
}

function desenharGrama(progresso) {
  noStroke();
  fill(lerpColor(color(120, 120, 120), color(34, 139, 34), progresso));
  rect(0, 350, width, 50);
}

// parte 3 a vida começa a ressurgir e vem a mensagem
function crescerFloresta() {
  if (frameCount % 15 === 0 && arvores.length < 20) {
    arvores.push(new Arvore(random(width), 350));
  }

  for (let arvore of arvores) {
    arvore.crescer();
    arvore.mostrar();
  }

  if (animais.length < 5 && frameCount % 60 === 0) {
    animais.push(new Animal(random(width), 330));
  }
}

function mostrarAnimais() {
  for (let animal of animais) {
    animal.mostrar();
  }
}

function mostrarTexto() {
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("A natureza se regenera, mas precisamos cuidar antes que seja tarde.", width / 2, 30);
}

// chãozinho
function desenharChao() {
  fill(100);
  rect(0, 350, width, 50);
}

//As floresta
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = 0;
  }

  crescer() {
    if (this.altura < 50) this.altura += 1;
  }

  mostrar() {
    stroke(0);
    fill(139, 69, 19); //o trornco das arvores
    rect(this.x, this.y - this.altura, 5, this.altura);
    fill(34, 139, 34); //as foia
    ellipse(this.x + 2, this.y - this.altura, 30, 30);

    //tentei fazer frutinhas
    fill(255, 0, 0);
    ellipse(this.x + 8, this.y - this.altura, 6, 6);
  }
}

// Aqui fica os animais, nessa parte eu tentei pedir ajuda ao chat gpt pra fazer eles ficarem no chão, só que não deu certo
class Animal {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    fill(255);
    ellipse(this.x, this.y, 15, 10); // corpo e
    ellipse(this.x + 5, this.y - 5, 8, 8); // cabeça
    fill(255, 182, 193);
    ellipse(this.x + 7, this.y - 7, 3, 8); // orelhas
    ellipse(this.x + 3, this.y - 7, 3, 8);
  }
}
//nos vídeos q eu vi, e uns amigos meus me recomendaram separar etapas, pra ficar mais facil de ir ajustando, admito que algumas coisas eu pedi pro chat gpt me ajudar a fazer, como por exemplo digitei o prompt:faça uma animação em time lapse sobre conscientização ambiental, não precisa ser muito complexo, simples mas bem feito, com estilo pixel art, se for retratar um elemento x, faça varias variações ao redor, como por exemplo, arvores crescendo ou algo assim, coloque vida no final com passáros e etc.  depois disso pedi pra ele me ensinar e explicar parte por parte e então comecei a fazer este, foi um desafio de quebrar a cabeça, mas foi diverido também, vou começar a aprender c+ com um amigo meu.